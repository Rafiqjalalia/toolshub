// YouTube Ad Skipper - Rafiq Digital
// Ye script har 300ms baad check karta hai ke ad chal rahi hai ya nahi
// Agar ad hai to: skip button click, video ko fast-forward, mute

(function () {
  "use strict";

  let lastMuteState = null;

  function log(msg) {
    // console.log("[AdSkipper] " + msg);
  }

  function clickSkipButtons() {
    const skipSelectors = [
      ".ytp-ad-skip-button",
      ".ytp-ad-skip-button-modern",
      ".ytp-skip-ad-button",
      "button.ytp-ad-skip-button-container",
      ".videoAdUiSkipButton"
    ];
    for (const sel of skipSelectors) {
      const btn = document.querySelector(sel);
      if (btn) {
        btn.click();
        log("Skip button clicked: " + sel);
      }
    }

    // Kabhi kabhi "Skip Ad" overlay text bhi hota hai jo clickable div hota hai
    const overlayCloseButtons = document.querySelectorAll(
      ".ytp-ad-overlay-close-button, .ytp-ad-overlay-close-container button"
    );
    overlayCloseButtons.forEach((btn) => btn.click());
  }

  function handleVideoAd() {
    const player = document.querySelector(".html5-video-player");
    const video = document.querySelector("video");
    if (!player || !video) return;

    const isAdShowing = player.classList.contains("ad-showing") ||
                         player.classList.contains("ad-interrupting");

    if (isAdShowing) {
      // Mute karo taake awaaz na aaye
      if (!video.muted) {
        video.muted = true;
        lastMuteState = false;
      }
      // Video ko end tak fast-forward kar do (ad khud khatam ho jayegi)
      if (video.duration && isFinite(video.duration)) {
        video.currentTime = video.duration;
      }
      // Playback speed max kar do taake jaldi khatam ho
      try {
        video.playbackRate = 16;
      } catch (e) {}

      clickSkipButtons();
    } else {
      // Ad khatam, mute wapas normal karo (agar humne mute kiya tha)
      if (lastMuteState === false) {
        video.muted = false;
        lastMuteState = null;
      }
      try {
        if (video.playbackRate === 16) {
          video.playbackRate = 1;
        }
      } catch (e) {}
    }
  }

  function hideBannerAds() {
    const bannerSelectors = [
      "ytd-display-ad-renderer",
      "ytd-promoted-sparkles-web-renderer",
      "ytd-companion-slot-renderer",
      "#player-ads",
      "ytd-ad-slot-renderer",
      ".ytd-in-feed-ad-layout-renderer",
      "tp-yt-paper-dialog:has(ytd-mealbar-promo-renderer)"
    ];
    bannerSelectors.forEach((sel) => {
      document.querySelectorAll(sel).forEach((el) => {
        el.style.display = "none";
      });
    });
  }

  function tick() {
    handleVideoAd();
    hideBannerAds();
  }

  // Har 300ms check karo - YouTube ka player dynamic hai (SPA)
  setInterval(tick, 300);

  // Page load aur navigation (YouTube SPA hai, page reload nahi hota)
  document.addEventListener("yt-navigate-finish", tick);
  window.addEventListener("load", tick);
})();
