const devices = [
  { name: "iPhone 14 Pro", w: 393, h: 852 },
  { name: "iPhone SE",     w: 375, h: 667 },
  { name: "Pixel 7",       w: 412, h: 915 },
  { name: "Samsung S21",   w: 360, h: 800 },
  { name: "iPad Mini",     w: 768, h: 1024 },
  { name: "iPad Air",      w: 820, h: 1180 },
  { name: "Desktop (HD)",  w: 1366, h: 768 }
];

const listEl = document.getElementById("deviceList");
const statusEl = document.getElementById("status");

// Rough guess for the popup window's own title bar / border thickness.
const CHROME_TITLEBAR_HEIGHT = 36;
const CHROME_BORDER_WIDTH = 4;

function openInDeviceWindow(deviceW, deviceH) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const url = tabs[0]?.url;
    if (!url) {
      statusEl.textContent = "Could not read current tab URL.";
      return;
    }

    chrome.system.display.getInfo((displays) => {
      const workArea = displays?.[0]?.workArea || { width: 1280, height: 800 };
      const maxW = workArea.width - 80;
      const maxH = workArea.height - 120;

      // Scale down only if the device is bigger than available screen space,
      // so the FULL device is always visible without scrolling.
      const scale = Math.min(1, maxW / deviceW, maxH / deviceH);
      const contentW = Math.round(deviceW * scale);
      const contentH = Math.round(deviceH * scale);

      chrome.windows.create(
        {
          url: url,
          type: "popup",
          width: contentW + CHROME_BORDER_WIDTH,
          height: contentH + CHROME_TITLEBAR_HEIGHT,
          top: 20,
          left: 20
        },
        (win) => {
          const tabId = win.tabs[0].id;
          statusEl.textContent = "Setting up device view...";

          function onUpdated(updatedTabId, info) {
            if (updatedTabId === tabId && info.status === "complete") {
              chrome.tabs.onUpdated.removeListener(onUpdated);
              applyEmulation(tabId, deviceW, deviceH, scale, url);
            }
          }
          chrome.tabs.onUpdated.addListener(onUpdated);
        }
      );
    });
  });
}

function applyEmulation(tabId, w, h, scale, url) {
  chrome.debugger.attach({ tabId }, "1.3", () => {
    if (chrome.runtime.lastError) {
      statusEl.textContent = "Emulation failed: " + chrome.runtime.lastError.message;
      return;
    }
    chrome.debugger.sendCommand(
      { tabId },
      "Emulation.setDeviceMetricsOverride",
      {
        width: w,
        height: h,
        deviceScaleFactor: 3,
        mobile: true,
        scale: scale
      },
      () => {
        chrome.debugger.sendCommand(
          { tabId },
          "Emulation.setTouchEmulationEnabled",
          { enabled: true },
          () => {
            // Reload so the site's own responsive JS (if any) re-checks
            // against the correct emulated viewport from a clean load.
            chrome.tabs.update(tabId, { url }, () => {
              statusEl.textContent =
                `Full device fit: ${w}×${h}` +
                (scale < 1 ? ` @ ${(scale * 100).toFixed(0)}% zoom` : "");
            });
          }
        );
      }
    );
  });
}

devices.forEach((d) => {
  const btn = document.createElement("button");
  btn.className = "device-btn";
  btn.innerHTML = `<span>${d.name}</span><span class="dim">${d.w}×${d.h}</span>`;
  btn.addEventListener("click", () => openInDeviceWindow(d.w, d.h));
  listEl.appendChild(btn);
});

document.getElementById("openCustom").addEventListener("click", () => {
  const w = parseInt(document.getElementById("customW").value, 10);
  const h = parseInt(document.getElementById("customH").value, 10);
  if (!w || !h) {
    statusEl.textContent = "Enter valid width & height.";
    return;
  }
  openInDeviceWindow(w, h);
});
