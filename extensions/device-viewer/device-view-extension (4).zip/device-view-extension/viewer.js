const devices = [
  { name: "iPhone 14 Pro", w: 393, h: 852 },
  { name: "iPhone SE",     w: 375, h: 667 },
  { name: "Pixel 7",       w: 412, h: 915 },
  { name: "Samsung S21",   w: 360, h: 800 },
  { name: "iPad Mini",     w: 768, h: 1024 },
  { name: "iPad Air",      w: 820, h: 1180 },
  { name: "Desktop (HD)",  w: 1366, h: 768 }
];

const params = new URLSearchParams(window.location.search);
const targetUrl = params.get("url") || "https://example.com";
let currentW = parseInt(params.get("w"), 10) || 393;
let currentH = parseInt(params.get("h"), 10) || 852;

const select = document.getElementById("deviceSelect");
const wInput = document.getElementById("wInput");
const hInput = document.getElementById("hInput");
const dimsEl = document.getElementById("dims");
const screenEl = document.getElementById("screen");
const iframeEl = document.getElementById("siteFrame");
const applyBtn = document.getElementById("applyBtn");

devices.forEach((d, i) => {
  const opt = document.createElement("option");
  opt.value = i;
  opt.textContent = `${d.name} (${d.w}×${d.h})`;
  select.appendChild(opt);
});

// Try to preselect matching device
const matchIndex = devices.findIndex(d => d.w === currentW && d.h === currentH);
select.value = matchIndex >= 0 ? matchIndex : 0;

function applySize(w, h) {
  currentW = w;
  currentH = h;
  screenEl.style.width = w + "px";
  screenEl.style.height = h + "px";
  iframeEl.style.width = w + "px";
  iframeEl.style.height = h + "px";
  wInput.value = w;
  hInput.value = h;
  dimsEl.textContent = `${w} × ${h} px`;
}

select.addEventListener("change", () => {
  const d = devices[select.value];
  applySize(d.w, d.h);
});

applyBtn.addEventListener("click", () => {
  const w = parseInt(wInput.value, 10);
  const h = parseInt(hInput.value, 10);
  if (w && h) applySize(w, h);
});

applySize(currentW, currentH);
iframeEl.src = targetUrl;
