let notes = [];
let selectedColor = "yellow";
let saveTimer = null;

const newNoteText = document.getElementById("newNoteText");
const addBtn = document.getElementById("addBtn");
const notesList = document.getElementById("notesList");
const emptyState = document.getElementById("emptyState");
const colorPicker = document.getElementById("colorPicker");
const saveIndicator = document.getElementById("saveIndicator");

function flashSaved() {
  saveIndicator.classList.add("show");
  clearTimeout(saveIndicator._t);
  saveIndicator._t = setTimeout(() => saveIndicator.classList.remove("show"), 900);
}

function loadNotes() {
  chrome.storage.local.get(["notes"], (res) => {
    notes = res.notes || [];
    render();
  });
}

function persist() {
  chrome.storage.local.set({ notes }, flashSaved);
}

function fmtTime(ts) {
  const d = new Date(ts);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" }) +
         " · " + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

function render() {
  notesList.innerHTML = notes.map(n => `
    <div class="note-card color-${n.color}" data-id="${n.id}">
      <div class="note-text" contenteditable="true" data-id="${n.id}">${escapeHtml(n.text)}</div>
      <div class="note-footer">
        <span class="note-time">${fmtTime(n.updated)}</span>
        <button class="note-delete" data-id="${n.id}">Delete</button>
      </div>
    </div>
  `).join("");

  emptyState.classList.toggle("show", notes.length === 0);

  notesList.querySelectorAll(".note-text").forEach(el => {
    el.addEventListener("input", () => {
      const id = el.dataset.id;
      const note = notes.find(n => n.id === id);
      if (!note) return;
      note.text = el.innerText;
      note.updated = Date.now();
      debouncedPersist();
    });
  });

  notesList.querySelectorAll(".note-delete").forEach(btn => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.id;
      notes = notes.filter(n => n.id !== id);
      persist();
      render();
    });
  });
}

function debouncedPersist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persist, 500);
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

colorPicker.addEventListener("click", (e) => {
  const swatch = e.target.closest(".swatch");
  if (!swatch) return;
  selectedColor = swatch.dataset.color;
  colorPicker.querySelectorAll(".swatch").forEach(s => s.classList.remove("active"));
  swatch.classList.add("active");
});

addBtn.addEventListener("click", addNoteFromInput);
newNoteText.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
    addNoteFromInput();
  }
});

function addNoteFromInput() {
  const text = newNoteText.value.trim();
  if (!text) return;
  notes.unshift({
    id: "n" + Date.now() + Math.random().toString(36).slice(2, 7),
    text,
    color: selectedColor,
    created: Date.now(),
    updated: Date.now()
  });
  newNoteText.value = "";
  persist();
  render();
}

document.addEventListener("DOMContentLoaded", loadNotes);
