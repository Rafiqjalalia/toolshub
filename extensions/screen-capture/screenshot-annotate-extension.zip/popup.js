document.getElementById("captureBtn").addEventListener("click", () => {
  const btn = document.getElementById("captureBtn");
  const hint = document.getElementById("hint");
  btn.disabled = true;
  btn.textContent = "Capturing...";

  chrome.tabs.captureVisibleTab(null, { format: "png" }, async (dataUrl) => {
    if (chrome.runtime.lastError || !dataUrl) {
      hint.textContent = "Could not capture this page.";
      btn.disabled = false;
      btn.textContent = "Capture This Page";
      return;
    }
    await chrome.storage.local.set({ screenshot: dataUrl, capturedAt: Date.now() });
    chrome.tabs.create({ url: chrome.runtime.getURL("editor.html") });
    window.close();
  });
});
