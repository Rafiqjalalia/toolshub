const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const toast = document.getElementById("toast");

let currentTool = "pen";
let currentColor = "#FF3B30";
let currentWidth = 4;
let undoStack = [];
let drawing = false;
let startX = 0, startY = 0;
let dragSnapshot = null;

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => toast.classList.remove("show"), 1600);
}

function pushUndo() {
  undoStack.push(canvas.toDataURL());
  if (undoStack.length > 25) undoStack.shift();
}

function loadScreenshot() {
  chrome.storage.local.get(["screenshot"], (res) => {
    if (!res.screenshot) {
      showToast("No screenshot found — capture one from the extension icon.");
      return;
    }
    const img = new Image();
    img.onload = () => {
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      ctx.drawImage(img, 0, 0);
      pushUndo();
    };
    img.src = res.screenshot;
  });
}

// ---------- Toolbar wiring ----------
document.querySelectorAll(".tool-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tool-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentTool = btn.dataset.tool;
  });
});

document.querySelectorAll(".color-swatch").forEach(sw => {
  sw.addEventListener("click", () => {
    document.querySelectorAll(".color-swatch").forEach(s => s.classList.remove("active"));
    sw.classList.add("active");
    currentColor = sw.dataset.color;
  });
});

document.getElementById("widthSlider").addEventListener("input", (e) => {
  currentWidth = parseInt(e.target.value, 10);
});

document.getElementById("undoBtn").addEventListener("click", () => {
  if (undoStack.length <= 1) return;
  undoStack.pop();
  const prev = undoStack[undoStack.length - 1];
  const img = new Image();
  img.onload = () => { ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.drawImage(img, 0, 0); };
  img.src = prev;
});

document.getElementById("clearBtn").addEventListener("click", () => {
  if (!confirm("Clear all annotations and reload the original screenshot?")) return;
  loadScreenshot();
  undoStack = [];
});

document.getElementById("downloadBtn").addEventListener("click", () => {
  const link = document.createElement("a");
  link.download = `screenshot-${Date.now()}.png`;
  link.href = canvas.toDataURL("image/png");
  link.click();
  showToast("Downloaded!");
});

document.getElementById("copyBtn").addEventListener("click", async () => {
  try {
    canvas.toBlob(async (blob) => {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      showToast("Copied to clipboard!");
    });
  } catch (e) {
    showToast("Copy failed — try Download instead.");
  }
});

// ---------- Coordinate helper (canvas may be scaled by CSS) ----------
function getPos(e) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  return { x: (e.clientX - rect.left) * scaleX, y: (e.clientY - rect.top) * scaleY };
}

// ---------- Drawing: Pen ----------
function drawPenStart(pos) {
  ctx.strokeStyle = currentColor;
  ctx.lineWidth = currentWidth;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(pos.x, pos.y);
}
function drawPenMove(pos) {
  ctx.lineTo(pos.x, pos.y);
  ctx.stroke();
}

// ---------- Drawing: Arrow ----------
function drawArrow(x1, y1, x2, y2) {
  const headlen = Math.max(12, currentWidth * 3);
  const angle = Math.atan2(y2 - y1, x2 - x1);
  ctx.strokeStyle = currentColor;
  ctx.fillStyle = currentColor;
  ctx.lineWidth = currentWidth;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - headlen * Math.cos(angle - Math.PI / 6), y2 - headlen * Math.sin(angle - Math.PI / 6));
  ctx.lineTo(x2 - headlen * Math.cos(angle + Math.PI / 6), y2 - headlen * Math.sin(angle + Math.PI / 6));
  ctx.closePath();
  ctx.fill();
}

// ---------- Drawing: Rectangle ----------
function drawRect(x1, y1, x2, y2) {
  ctx.strokeStyle = currentColor;
  ctx.lineWidth = currentWidth;
  ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
}

// ---------- Drawing: Text ----------
function placeText(pos) {
  const value = prompt("Enter text:");
  if (!value) return;
  pushUndo();
  ctx.fillStyle = currentColor;
  ctx.font = `${16 + currentWidth * 3}px Segoe UI, sans-serif`;
  ctx.textBaseline = "top";
  ctx.fillText(value, pos.x, pos.y);
}

function restoreSnapshot(dataUrl, cb) {
  const img = new Image();
  img.onload = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0);
    if (cb) cb();
  };
  img.src = dataUrl;
}

// ---------- Mouse events ----------
canvas.addEventListener("mousedown", (e) => {
  const pos = getPos(e);
  startX = pos.x; startY = pos.y;

  if (currentTool === "text") {
    placeText(pos);
    return;
  }

  drawing = true;
  dragSnapshot = canvas.toDataURL();

  if (currentTool === "pen") {
    drawPenStart(pos);
  }
});

canvas.addEventListener("mousemove", (e) => {
  if (!drawing) return;
  const pos = getPos(e);

  if (currentTool === "pen") {
    drawPenMove(pos);
  } else if (currentTool === "arrow" || currentTool === "rect") {
    restoreSnapshot(dragSnapshot, () => {
      if (currentTool === "arrow") drawArrow(startX, startY, pos.x, pos.y);
      else drawRect(startX, startY, pos.x, pos.y);
    });
  }
});

window.addEventListener("mouseup", () => {
  if (!drawing) return;
  drawing = false;
  pushUndo();
});

document.addEventListener("DOMContentLoaded", loadScreenshot);
