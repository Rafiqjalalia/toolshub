/**
 * content.js — injected into every page.
 * Listens for messages from popup / background to insert Urdu text
 * into the currently focused input / textarea / contenteditable.
 */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "insertText") {
    insertIntoFocusedElement(msg.text);
    sendResponse({ ok: true });
  }
  if (msg.action === "getSelection") {
    sendResponse({ text: window.getSelection().toString() });
  }
});

function insertIntoFocusedElement(text) {
  const el = document.activeElement;
  if (!el) return;

  // Input / textarea
  if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
    const start = el.selectionStart;
    const end   = el.selectionEnd;
    const val   = el.value;
    el.value = val.slice(0, start) + text + val.slice(end);
    el.selectionStart = el.selectionEnd = start + text.length;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    return;
  }

  // contenteditable
  if (el.isContentEditable) {
    document.execCommand("insertText", false, text);
    return;
  }
}
