/**
 * background.js — Service worker for Urdu Extractor extension.
 * Handles context-menu integration (right-click → transliterate).
 */

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus?.create({
    id: "transliterate-selection",
    title: "Transliterate to اردو",
    contexts: ["selection"],
  });
});

chrome.contextMenus?.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "transliterate-selection" && info.selectionText) {
    // We can't import transliterator.js in service worker directly,
    // so send a message to content script which will do the work,
    // OR we inline a minimal transliteration here.
    const text = info.selectionText;
    const result = transliterateInline(text);

    chrome.tabs.sendMessage(tab.id, {
      action: "insertText",
      text: result,
    });
  }
});

/**
 * Minimal inline transliteration (service-worker compatible).
 * Full version lives in transliterator.js (popup context).
 */
function transliterateInline(text) {
  const CHAR_MAP = [
    ["kh","خ"],["sh","ش"],["ch","چ"],["gh","غ"],
    ["ph","پھ"],["th","تھ"],["dh","دھ"],["bh","بھ"],
    ["jh","جھ"],["zh","ژ"],["ng","نگ"],
    ["oo","و"],["ee","ی"],["aa","ا"],
    ["a","ا"],["b","ب"],["p","پ"],["t","ت"],["j","ج"],
    ["h","ہ"],["d","د"],["z","ذ"],["r","ر"],["s","س"],
    ["g","گ"],["f","ف"],["q","ق"],["k","ک"],["l","ل"],
    ["m","م"],["n","ن"],["w","و"],["y","ی"],
    ["e",""],["i","ی"],["o","و"],
  ];

  const WORD_MAP = {
    "main":"میں","mein":"میں","mujhe":"مجھے","tum":"تم",
    "aap":"آپ","woh":"وہ","yeh":"یہ","ye":"یہ","hum":"ہم",
    "hai":"ہے","hain":"ہیں","tha":"تھا","thi":"تھی","the":"تھے",
    "ga":"گا","gi":"گی","ge":"گے",
    "karta":"کرتا","kar":"کر","kiya":"کیa",
    "aur":"اور","ya":"یا","par":"پر","se":"سے","ko":"کو",
    "nahi":"نہیں","nahin":"نہیں","bhi":"بھی",
    "pakistan":"پاکستان","lahore":"لاہور","karachi":"کراچی",
    "islamabad":"اسلام آباد","urdu":"اردو",
    "bohat":"بہت","acha":"اچھa","bura":"برا",
    "inshallah":"انشاءاللہ","mashallah":"ماشاءاللہ",
    "assalamu":"السلام","alaikum":"علیکم",
    "aaj":"آj","kal":"کl","ab":"اب",
  };

  const sorted = CHAR_MAP.sort((a,b) => b[0].length - a[0].length);

  function transliterateWord(w) {
    const lo = w.toLowerCase();
    if (WORD_MAP[lo]) return WORD_MAP[lo];
    let r = "", i = 0;
    while (i < lo.length) {
      let m = false;
      for (const [rom, urdu] of sorted) {
        if (lo.substring(i, i + rom.length) === rom) {
          r += urdu; i += rom.length; m = true; break;
        }
      }
      if (!m) { r += lo[i]; i++; }
    }
    return r;
  }

  return text.replace(/\s+/g, " ").trim()
    .match(/[A-Za-z]+|[^\s]/g)
    ?.map(t => /^[A-Za-z]+$/.test(t) ? transliterateWord(t) : t)
    .join(" ") ?? text;
}
