/**
 * OCR module — Tesseract.js based, fully offline Urdu text extraction.
 * Uses bundled worker.min.js for Chrome extension compatibility.
 */

let _worker = null;

/**
 * Get the extension-relative URL for a file.
 */
function getExtURL(path) {
  return chrome.runtime.getURL(path);
}

/**
 * Initialise (or re-use) the Tesseract worker.
 * @param {string}   lang       Tesseract language code, e.g. "urd"
 * @param {Function} onProgress callback(progress 0..1, statusText)
 */
async function initOCRWorker(lang = "urd", onProgress) {
  if (_worker && _worker._lang === lang) return _worker;

  // Terminate old worker if language changed
  if (_worker) {
    await _worker.terminate();
    _worker = null;
  }

  const workerPath = getExtURL("lib/worker.min.js");
  const corePath   = "https://cdn.jsdelivr.net/npm/tesseract.js-core@5/";

  const { createWorker, OEM } = Tesseract;

  _worker = await createWorker(lang, OEM.LSTM_ONLY, {
    workerPath:  workerPath,
    corePath:    corePath,
    langPath:    "https://cdn.jsdelivr.net/npm/tesseract.js-data@4/",
    logger: (m) => {
      if (onProgress && m.progress !== undefined) {
        onProgress(m.progress, m.status || "");
      }
    },
  });

  _worker._lang = lang;
  return _worker;
}

/**
 * Recognise text from an image (File, Blob, or data-URL string).
 * @param {string}              lang        Tesseract lang code
 * @param {File|Blob|string}    imageSource
 * @param {Function}            onProgress  (progress 0..1, status)
 * @returns {Promise<string>}   Recognised text
 */
async function ocrRecognise(lang, imageSource, onProgress) {
  const worker = await initOCRWorker(lang, onProgress);
  const { data } = await worker.recognize(imageSource);
  return data.text.trim();
}

/**
 * Terminate the worker (free memory).
 */
async function ocrTerminate() {
  if (_worker) {
    await _worker.terminate();
    _worker = null;
  }
}
