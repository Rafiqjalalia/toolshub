/**
 * Roman Urdu → Nastaleeq Urdu — Rule-Based Transliteration Engine
 * Offline, koi internet nahi chahiye.
 */

const CHAR_MAP = [
  // digraphs / trigraphs (longest first)
  ["kh","خ"],["sh","ش"],["ch","چ"],["gh","غ"],
  ["ph","پھ"],["th","تھ"],["dh","دھ"],["bh","بھ"],
  ["jh","جھ"],["zh","ژ"],["ng","نگ"],
  ["oo","و"],["ee","ی"],["aa","ا"],["ai","ائ"],["au","اء"],

  // single letters
  ["a","ا"],["b","ب"],["p","پ"],["t","ت"],["j","ج"],
  ["H","ح"],["h","ہ"],["d","د"],["z","ذ"],["r","ر"],
  ["s","س"],["g","گ"],["f","ف"],["q","ق"],["k","ک"],
  ["l","ل"],["m","م"],["n","ن"],["w","و"],["v","و"],["y","ی"],
  ["e",""],["i","ی"],["o","و"],
];

const WORD_MAP = {
  // Pronouns
  "main":"میں","mein":"میں","mi":"میں",
  "mujhe":"مجھے","mujhko":"مجھکو","mujhse":"مجھ سے",
  "tum":"تم","tumhe":"تمہیں","tumhein":"تمہیں","tumse":"تم سے",
  "aap":"آپ","aapko":"آپکو",
  "woh":"وہ","wo":"وہ","wohi":"وہی",
  "yeh":"یہ","ye":"یہ","yahi":"یہی","yai":"یہی",
  "hum":"ہم","ham":"ہم","humhein":"ہمیں","hamko":"ہمکو",
  "mera":"میرا","meri":"مری","mere":"میرے",
  "uska":"اسکا","uski":"اسکی","uske":"اسکے",
  "iska":"اسکا","iski":"اسکی","iske":"اسکے",
  "unka":"انکا","unki":"انکی","unke":"انکے",
  "apna":"اپنا","apni":"اپنی","apne":"اپنے",

  // Verbs / auxiliaries
  "hai":"ہے","hain":"ہیں","ha":"ہے",
  "hon":"ہوں","hoon":"ہوں","ho":"ہو",
  "tha":"تھا","thi":"تھی","the":"تھے","thay":"تھے",
  "gaya":"گیا","gayi":"گئی","gaye":"گئے",
  "ga":"گا","gi":"گی","ge":"گے",
  "karta":"کرتا","karti":"کرتی","karte":"کرتے",
  "kar":"کر","kiya":"کیا","karna":"کرنا",
  "karein":"کریں","karo":"کرو",
  "ja":"جا","jao":"جاؤ","jana":"جانا",
  "raha":"رہا","rahi":"رہی","rahe":"رہے",
  "diya":"دیا","di":"دی","de":"دے","den":"دیں",
  "leta":"لیتا","leti":"لیتی","le":"لے","lo":"لو",
  "aa":"آ","aaya":"آیا","aayi":"آئی","aaye":"آئے",
  "mila":"ملا","mili":"ملی","mile":"ملے",
  "chal":"چل","chala":"چلا","chali":"چلی","chale":"چلے",
  "bol":"بول","bola":"بولا","boli":"بولی","bole":"بولے",
  "likh":"لکھ","likha":"لکھا","likhi":"لکھی","likhe":"لکھے",
  "padh":"پڑھ","padha":"پڑھا","padhi":"پڑھی",
  "samajh":"سمجھ","samjha":"سمجھا",
  "jaanta":"جانتا","jaanti":"جانتی","jaan":"جان",
  "chahiye":"چاہیے","chahe":"چاہے","chahta":"چاہتا","chahti":"چاہتی",
  "sakta":"سکتا","sakti":"سکتی","sakte":"سکتے",
  "hona":"ہونا","hoga":"ہوگا","hogi":"ہوگی","hone":"ہونے",
  "hua":"ہوا","hui":"ہوئی","hue":"ہوئے",
  "seekhna":"سیکھنا","seekhni":"سیکھنی","seekh":"سیکھ",
  "seekhta":"سیکھتا","seekhti":"سیکھتی","seekho":"سیکھو",

  // Conjunctions / prepositions / adverbs
  "aur":"اور","ya":"یا","par":"پر","per":"پر","pe":"پر",
  "saath":"ساتھ","se":"سے","ko":"کو",
  "ke":"کے","ki":"کی","ka":"کا","ne":"نے",
  "na":"نہ","nahi":"نہیں","nahin":"نہیں",
  "bhi":"بھی","abhi":"ابھی","sirf":"صرف","bas":"بس",
  "to":"تو","phir":"پھر","lekin":"لیکن","magar":"مگر",
  "agar":"اگر","warna":"ورنا",
  "kyunke":"کیونکہ","kyunki":"کیونکہ","chunki":"چونکی",
  "kisi":"کسی","kuch":"کچھ",  "kya":"کیا","kyun":"کیوں",
  "kaise":"کیسے","kaisa":"کیسا","kaisi":"کیسی",
  "kahan":"کہاں","kahin":"کہیں",
  "jab":"جب","tab":"تب","baad":"بعد","pehle":"پہلے",
  "jaise":"جیسے","jaisa":"جیسا","jaisi":"جیسی",
  "isliye":"اس لیے","liye":"لیے",
  "wala":"والا","wali":"والی","wale":"والے",
  "aaj":"آج","kal":"کل","ab":"اب","bohat":"بہت",
  "zyada":"زیادہ","kam":"کم","har":"ہر","koi":"کوئی","sab":"سب",
  "wahan":"وہاں","yahan":"یہاں","jahan":"جہاں",
  "idhar":"ادھر","samne":"سامنے","piche":"پیچھے","aage":"آگے",
  "andar":"اندر","bahar":"باہر","upar":"اوپر","neeche":"نیچے",
  "pass":"پاس","door":"دور","baghair":"بغیر",
  "zara":"ذرا","jaldi":"جلدی","der":"دیر",

  // Greetings / expressions
  "assalamu":"السلام","assalam":"السلام","alaikum":"علیکم",
  "salaam":"سلام","marhaba":"مرحبا",
  "bismillah":"بِسْمِ اللہ","inshallah":"انشاءاللہ",
  "mashallah":"ماشاءاللہ","alhamdulillah":"الحمدللہ",
  "subhanallah":"سبحان اللہ","allhafiz":"اللہ حافظ",
  "khuda hafiz":"خدا حافظ",
  "shukriya":"شکریہ","mamnoon":"ممنون","ji":"جی",
  "haan":"ہاں","bilkul":"بالکل","zaroor":"ضرور","maaf":"معاف",

  // Common nouns
  "log":"لوگ","din":"دن","raat":"رات","subah":"صبح",
  "shaam":"شام","waqt":"وقت","ghar":"گھر",
  "duniya":"دنیا","zindagi":"زندگی","naam":"نام",
  "baat":"بات","kaam":"کام","insan":"انسان",
  "dost":"دوست","dosti":"دوستی","zuban":"زبان",
  "mulk":"ملک","shehar":"شہر","gaon":"گاؤں",
  "pani":"پانی","khana":"کھانا","chai":"چائے",
  "bhai":"بھائی","behan":"بہن","walid":"والد","walida":"والدہ",
  "abba":"ابا","ammi":"امی","ustad":"استاد",
  "hukumat":"حکومت","qanoon":"قانون","sarkar":"سرکار",
  "azad":"آزاد","jung":"جنگ","aman":"امن",
  "ishq":"عشق","mohabbat":"محبت","nafrat":"نفرت",
  "wafa":"وفا","sach":"سچ","haq":"حق",
  "masla":"مسلہ","sawal":"سوال","jawab":"جواب",
  "khushi":"خوشی","gham":"غم","dard":"درد",
  "sehat":"صحت","bimari":"بیماری","dawa":"دوا",
  "ilm":"علم","taleem":"تعلیم",
  "urdu":"اردو","haal":"حال",

  // Pakistan / cities
  "pakistan":"پاکستان","lahore":"لاہور","karachi":"کراچی",
  "islamabad":"اسلام آباد","peshawar":"پشاور","quetta":"کوئٹہ",
  "multan":"ملتان","faisalabad":"فیصل آباد",
  "kashmir":"کشمیر","punjab":"پنجاب","sindh":"سندھ",
  "balochistan":"بلوچستان",

  // Common adjectives
  "accha":"اچھا","acha":"اچھا","bura":"برا","theek":"ٹھیک",
  "naya":"نیا","purana":"پرانا","chota":"چھوٹا","bara":"بڑا",
  "lamba":"لمبا","tez":"تیz","dheema":"دھیما",
  "garam":"گرم","thanda":"ٹھنڈa","sakht":"سخت","naram":"نaram",
  "meetha":"میٹھa","khush":"خوش","udaas":"اداس",
  "sundar":"خوبصورت","khubsurat":"خوبصورt",
  "mushkil":"مشکل","aasaan":"آسان",
  "mumkin":"ممکن","zaroori":"ضروری","bekar":"بیکار",
  "bohot":"بہت",

  // Animals
  "kutta":"کتا","billi":"بلی","ghora":"گھوڑا",
  "hathi":"ہاتھی","sher":"شیر","kabootar":"کبوتر",
  "machli":"مچھلی","murgi":"مرغی","anda":"انڈا",
  "saamp":"سانپ","bichhoo":"بچھو",

  // Misc common
  "wakt":"وقت","zamana":"زمانہ","daur":"دور",
  "accha":"اچھa","bura":"برا","theek":"ٹھیk",
  "sahi":"صحیح","galat":"غلط",
  "aqal":"عقل","zehan":"ذہن","soch":"سوچ",
  "fikr":"فکر","himmat":"ہمت","jazba":"جذبہ",
  "koshish":"کوشش","mehnat":"محنت",
  "kamyabi":"کامیابi","naakaami":"ناکامi",
  "ummeed":"امید","mayoosi":"مایوسi",
  "waada":"وعدہ","irada":"ارادہ",
  "raaz":"راaz","kissa":"قصہ","kahani":"کہانی",
  "waqea":"واقعہ","haadsa":"حادثہ",
  "dil":"دل","dimagh":"دماغ","jism":"جسم","rooh":"روح",
  "saans":"سانس","neend":"نیند","khwab":"خواب",
  "aankh":"آنkh","kaan":"کان","naak":"ناک","munh":"منہ",
  "hath":"ہاتھ","pair":"پair","sir":"سر","gardan":"گردن",
  "seena":"سینہ","kamar":"کمر","pait":"پیٹ",
  "khoon":"خون","haddi":"ہڈi","gosht":"گوشت",
  "baal":"بال","daant":"دانت","aankhen":"آنkhیں",
  "haath":"ہاتھ","pair":"پair",
  "kapra":"کپڑa","joota":"جوتا","topi":"ٹوپi",
  "kursi":"کرسی","mez":"میز","darwaza":"دروازہ",
  "khidki":"کھڑکi","deewar":"دیوار","chhat":"چھت",
  "zameen":"زمین","asman":"آسمان","pahar":"پہاڑ",
  "darya":"دریا","jheel":"جھیل","samundar":"سمندر",
  "bagh":"باغ","phool":"پھول","darakht":"درخت",
  "patte":"پتے","phal":"پھل","sabzi":"سبزی",
  "mirch":"مرچ","namak":"نمک","cheeni":"چینی",
  "shakkar":"شکر","gosht":"گوشت",
  "sona":"سونا","chandi":"چاندی","loha":"لوہا",
  "heera":"ہیرا","moti":"موتی","patthar":"پتھر",
  "aag":"آگ","hawa":"ہوا","mitti":"مٹی","ret":"ریت",
  "lakri":"لکڑی","kanch":"کانچ",

  // Numbers
  "aik":"ایک","ek":"ایک","do":"دو","teen":"تین",
  "char":"چار","paanch":"پانچ","chhe":"چھ","saat":"سات",
  "aath":"آٹھ","nau":"نو","dus":"دس",
  "hazaar":"ہزار","lakh":"لاکھ","crore":"کروڑ",

  // Common mixed
  "rupay":"روپے","paisa":"پیسہ","paise":"پیسے",
  "dollar":"ڈالر","bazaar":"بازار","dukan":"دکان",
  "kamra":"کمرہ","kamre":"کمرے",
  "bazaar":"بازار","sarkari":"سرکارi","gharelu":"گھریل",
  "desh":"دیش","qomi":"قومi","siasi":"سیاسi",
  "khaas":"خاص","aam":"عام",
  "itla":"اطلاع","waqea":"واقعہ","khabar":"خبر",
};

// Sort char map longest-first
const _sortedCharMap = CHAR_MAP.sort((a,b) => b[0].length - a[0].length);

function charTransliterate(text) {
  let result = "";
  let i = 0;
  while (i < text.length) {
    let matched = false;
    for (const [roman, urdu] of _sortedCharMap) {
      if (text.substring(i, i + roman.length) === roman) {
        result += urdu;
        i += roman.length;
        matched = true;
        break;
      }
    }
    if (!matched) {
      result += text[i];
      i++;
    }
  }
  return result;
}

function transliterateWord(word) {
  const lower = word.toLowerCase();
  if (WORD_MAP[lower] !== undefined) return WORD_MAP[lower];
  return charTransliterate(lower);
}

/**
 * Transliterate a full Roman Urdu string to Urdu script.
 */
function transliterate(text) {
  text = text.replace(/\s+/g, " ").trim();
  const tokens = text.match(/[A-Za-z\u0600-\u06FF]+|[^\s]/g) || [];
  return tokens.map(tok => {
    return /^[A-Za-z]+$/.test(tok) ? transliterateWord(tok) : tok;
  }).join(" ");
}
