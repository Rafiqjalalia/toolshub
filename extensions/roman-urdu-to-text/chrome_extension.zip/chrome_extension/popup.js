/**
 * popup.js — glue between UI and transliteration / OCR engines.
 */

document.addEventListener("DOMContentLoaded", () => {
  // ── Tab switching ────────────────────────────────────────────────────
  const tabs = document.querySelectorAll(".tab");
  const contents = document.querySelectorAll(".tab-content");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      contents.forEach((c) => c.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById("tab-" + tab.dataset.tab).classList.add("active");
    });
  });

  // ── Transliterate tab ────────────────────────────────────────────────
  const romanInput  = document.getElementById("roman-input");
  const urduOutput  = document.getElementById("urdu-output");
  const btnTranslit = document.getElementById("btn-transliterate");
  const btnCopy     = document.getElementById("btn-copy-translit");
  const btnSwap     = document.getElementById("btn-swap");

  function doTransliterate() {
    const text = romanInput.value.trim();
    if (!text) return;
    urduOutput.value = transliterate(text);
  }

  btnTranslit.addEventListener("click", doTransliterate);

  // Live transliteration on Enter (Shift+Enter for newline)
  romanInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      doTransliterate();
    }
  });

  // Live typing: transliterate after 300ms pause
  let typingTimer;
  romanInput.addEventListener("input", () => {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(doTransliterate, 300);
  });

  btnCopy.addEventListener("click", () => {
    const text = urduOutput.value;
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      btnCopy.textContent = "✓ Copied!";
      setTimeout(() => (btnCopy.textContent = "📋 Copy اردو"), 1500);
    });
  });

  btnSwap.addEventListener("click", () => {
    const tmp = romanInput.value;
    romanInput.value = urduOutput.value;
    urduOutput.value = tmp;
  });

  // ── OCR tab ──────────────────────────────────────────────────────────
  const dropZone    = document.getElementById("drop-zone");
  const fileInput   = document.getElementById("file-input");
  const ocrPreview  = document.getElementById("ocr-preview");
  const previewImg  = document.getElementById("preview-img");
  const ocrLang     = document.getElementById("ocr-lang");
  const btnOCR      = document.getElementById("btn-ocr");
  const ocrProgress = document.getElementById("ocr-progress");
  const progressFill= document.getElementById("progress-fill");
  const progressText= document.getElementById("progress-text");
  const ocrOutput   = document.getElementById("ocr-output");
  const btnCopyOCR  = document.getElementById("btn-copy-ocr");
  const btnClearOCR = document.getElementById("btn-clear-ocr");

  let selectedFile = null;

  // Click to open file picker
  dropZone.addEventListener("click", () => fileInput.click());

  fileInput.addEventListener("change", (e) => {
    if (e.target.files.length) handleFile(e.target.files[0]);
  });

  // Drag & drop
  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("dragover");
  });
  dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("dragover");
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) handleFile(file);
  });

  function handleFile(file) {
    selectedFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      previewImg.src = e.target.result;
      ocrPreview.hidden = false;
      btnOCR.disabled = false;
    };
    reader.readAsDataURL(file);
  }

  // Run OCR
  btnOCR.addEventListener("click", async () => {
    if (!selectedFile) return;

    btnOCR.disabled = true;
    ocrProgress.hidden = false;
    progressFill.style.width = "0%";
    progressText.textContent = "Loading Tesseract...";

    try {
      const lang = ocrLang.value;
      const text = await ocrRecognise(lang, selectedFile, (pct, status) => {
        progressFill.style.width = Math.round(pct * 100) + "%";
        if (status) progressText.textContent = status;
      });

      ocrOutput.value = text;
      progressFill.style.width = "100%";
      progressText.textContent = "Done!";
      setTimeout(() => (ocrProgress.hidden = true), 1200);
    } catch (err) {
      progressText.textContent = "Error: " + err.message;
      progressFill.style.width = "0%";
    } finally {
      btnOCR.disabled = false;
    }
  });

  // Copy OCR result
  btnCopyOCR.addEventListener("click", () => {
    const text = ocrOutput.value;
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      btnCopyOCR.textContent = "✓ Copied!";
      setTimeout(() => (btnCopyOCR.textContent = "📋 Copy Text"), 1500);
    });
  });

  // Clear OCR
  btnClearOCR.addEventListener("click", () => {
    selectedFile = null;
    fileInput.value = "";
    ocrPreview.hidden = true;
    ocrOutput.value = "";
    btnOCR.disabled = true;
    ocrProgress.hidden = true;
  });
});
